/*
--문제점--
1. sharedVariable 검색이 하드코딩된 변수명
2. thread 찾는것이 하드코딩된 함수명
4. instrumenter가 공유변수를 하나만 기록함
*/

#include "llvm/ADT/Statistic.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/Pass.h"
#include "llvm/Support/raw_ostream.h"
#include <iostream>
#include <list>
#include "llvm/IR/DerivedTypes.h"
#include <omp.h>
#include <stdlib.h>
#include <map>

using namespace std;
using namespace llvm;

unsigned int cnt = 1;

#define DEBUG_TYPE "filter"

namespace {
    struct Filter: public ModulePass {
        
        static char ID;
        Filter(): ModulePass(ID) {}

        virtual bool doInitialization(Module &M) {
            Mod = &M;
        }

        void insert_Func(Instruction *I, int lockID, int svID) {  //, l_locks *ncs, l_locks *cs) {

            IRBuilder<> IRB(I);
			Type *argTy = Type::getInt32Ty(Mod->getContext()); 
			FunctionType *fTy=FunctionType::get(IntegerType::get(Mod->getContext(), 32), std::vector
			<Type*>(2, argTy), true);	

            checkReadFunc=Mod->getOrInsertFunction("checkRead", fTy);
            checkWriteFunc=Mod->getOrInsertFunction("checkWrite", fTy); 

            std::vector <Value *> Args;
			Args.push_back(ConstantInt::get(IRB.getInt32Ty(),(uint32_t)svID));
			Args.push_back(ConstantInt::get(IRB.getInt32Ty(),(uint32_t)lockID));
			

            if(isa<LoadInst>(I))
            {
                I->getParent()->getInstList().insert
                    (I->getIterator(), CallInst::Create(checkReadFunc, Args,""));
            }
            else if(isa<StoreInst>(I))
            {
                 I->getParent()->getInstList().insert
                     (I->getIterator(), CallInst::Create(checkWriteFunc, Args,""));
            }

        }

        bool runOnModule(Module &M) override {
            int cnt = 0;
            int cnt1 = 0; int cnt2 = 0;
            int res; char str1[]="lock";
            string variableName;
            errs().changeColor(raw_ostream::BLUE);
            errs() << "Module " << M.getName()<<" ...\n";

            for(Module::global_iterator gs=M.global_begin(), ge=M.global_end(); gs!=ge; ++gs) {
                errs().changeColor(raw_ostream::RED);
                errs() << "GloVar::iterator " << gs->getName() <<" ...\n";  //<< " ID" << svmap.size() <<" " << gs->getName().size() 

                if(gs->getName().size() > 0)
                {
                    variableName = gs->getName();
                    svmap.insert(make_pair(variableName, svmap.size()));
                    errs().resetColor();
                    errs()<<"pushSV: Name("<< gs->getName() << ") ID(" << svmap.size() - 1 << ")" <<"\n";

                }

				// if (gs->getName()=="sharedVar")
				// {
				// 	sharedGV=dyn_cast<GlobalVariable> (gs);
				// }
                
                // char str1[]="lock";
                // char str2[100]=((char*)gs->getName());
                // res= strncmp(str2, str1, 4);
                // if(res==0)
                // {
                //     errs() << "lockGV \n";
                //     if (cnt1<5)
                //     {
                //         lock1[cnt1++].sharedVar = dyn_cast<GlobalVariable> (sharedGV);
                //     }
                //     else if (cnt1>=5)
                //     {
                //         lock2[cnt2++].sharedVar = dyn_cast<GlobalVariable> (sharedGV);
                //     }
                // }
            }
			unsigned int j = 0;
			unsigned int tmp = 1;
            string cur_lock = "non-critical";
            lockmap.insert(make_pair(cur_lock, 0));

            for(Module::iterator F=M.begin(); F!=M.end(); ++F) {
                errs().changeColor(raw_ostream::GREEN);
                errs() << "Function::iterator " << F->getName()<<" ...\n";
                errs().resetColor();

                string functionName = F->getName();
                if(functionName == "checkRead" || 
                    functionName == "checkWrite" || 
                    functionName == "search" || 
                    functionName == "append" ||
                    functionName == "showResult")
                {
                    continue;
                }

				string mutex_cnt[100];
                unsigned int loadnum=0;
				unsigned int storenum=0;
							
                for (Function::iterator BB=F->begin(), EE=F->end(); BB!=EE; ++BB) {
                    errs().changeColor(raw_ostream::YELLOW);
                    errs() << "BasicBlock::iterator" << BB->getName()<< " ...\n";                    
                    errs().resetColor();

                    for (BasicBlock::iterator I=BB->begin(), E=BB->end(); I!=E; ++I) {
                        for (Use &U : I->operands()) {
								unsigned int k;
                                if (U->getName()=="__kmpc_critical") {
									// j=tmp;

																	
                                    errs()<<"pushLock:"<<(*I->getOperand(2)).getName()<<"\n";
                                    cur_lock = (*I->getOperand(2)).getName();
                                    lockmap.insert(make_pair(cur_lock, lockmap.size()));
                                    

                                        // for (k=1; k<=j; k++)
                                        // {
                                        //     if (mutex_cnt[k]==(*I->getOperand(2)).getName()) {
										// 		j=k;												
                                        //         break;
                                        //     }
                                        //     else if (j==k)
                                        //     {   
                                        //         mutex_cnt[j]=(*I->getOperand(2)).getName();
										// 		if (F->getName()=="_Z5task1i") 
										// 		{
                                        //         	lock1[j]={0,0,&sharedGV,0};
                                        //         } else if (F->getName()=="_Z5task2i") 
										// 		{
                                        //         	lock2[j]={0,0,&sharedGV,0};
                                        //         }
										// 		tmp++;
                                        //         break;
                                        //     }
                                        // } //for fin
								} //if_lock fin		

							 else if (U->getName()=="__kmpc_end_critical") {
								errs().changeColor(raw_ostream::GREEN);
								errs() <<"non-critical\n" ;								
                                cur_lock = "non-critical";   //.clear();
								// j=0;
							  }
                            errs().resetColor();
                        }// for (Use ~)

						if(F->getName()=="_Z5task1i" || F->getName()=="_Z5task2i")
						{
                           if (isa<LoadInst> (I) || isa<StoreInst>(I)) { 
		                       for (unsigned int i=0; i<I->getNumOperands(); i++)
		                       {
                                   variableName = I->getOperand(i)->getName();
                                   if(svmap.count(variableName) > 0)
                                   {
                                        errs().resetColor();
										Instruction *it=dyn_cast<Instruction> (I);
                                        insert_Func(it, lockmap[cur_lock], svmap[variableName]);
                                   }
		                        //    if (sharedGV==dyn_cast<GlobalVariable>(I->getOperand(i)))
		                        //    {//공유변수에 접근함을 확인하면 그 전에 insert_Func 넣기 
								// 		errs().resetColor();
								// 		Instruction *it=dyn_cast<Instruction> (I);

								// 		if(F->getName()=="_Z5task1i" )
								// 		{                                            
								// 			// insert_Func(it, &lock1[0], &lock1[j]);
                                //             insert_Func(it, lockmap[cur_lock]);
								// 		}
								// 		else if (F->getName()=="_Z5task2i")
								// 		{
								// 			// insert_Func(it, &lock2[0], &lock2[j]);
                                //             insert_Func(it, lockmap[cur_lock]);
								// 		}
		                        //     }
		                        }
                            } //스레드 함수를 위한 if문 끝 
						} 
                } //basic block 끝 
            }//Function

            }//Module
        return false;
        }// end of runOnModule

        private:
            Module *Mod;
            Constant *checkReadFunc;
            Constant *checkWriteFunc;
			//Constant *PrintFunc;
            //GlobalVariable *GV;
            GlobalVariable *sharedGV;
            GlobalVariable *lockGV;
            //GlobalVariable llocks[10];
            map<string,int> lockmap;
            map<string,int> svmap;
    };
    
}
     
char Filter::ID=0;
static RegisterPass<Filter> X("filter", "filter pass");
