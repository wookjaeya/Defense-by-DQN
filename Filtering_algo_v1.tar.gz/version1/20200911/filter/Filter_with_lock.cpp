#include "llvm/ADT/Statistic.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/Pass.h"
#include "llvm/Support/raw_ostream.h"
#include <iostream>
#include <list>
//#include <llvm/Support/Mutex.h>
#include "llvm/IR/DerivedTypes.h"
#include "accessFilter.h"
#include <omp.h>

using namespace std;
using namespace llvm;

unsigned int cnt=1;

#define DEBUG_TYPE "filter"

namespace {
    struct Filter: public ModulePass {
        
        static char ID;
        Filter(): ModulePass(ID) {}

        virtual bool doInitialization(Module &M) {
            Mod = &M;
        }

        void insert_Func(Instruction *I, l_locks *ncs, l_locks *cs) {

            IRBuilder<> IRB(I);
			Type *argTy = Type::getInt32Ty(Mod->getContext()); 
			FunctionType *fTy=FunctionType::get(IntegerType::get(Mod->getContext(), 32), std::vector
			<Type*>(2, argTy), true);	

            checkReadFunc=Mod->getOrInsertFunction("checkRead", fTy);
            checkWriteFunc=Mod->getOrInsertFunction("checkWrite", fTy); 

            std::vector <Value *> Args;
			Args.push_back(ConstantInt::get(IRB.getInt32Ty(),(uint32_t)ncs));
			Args.push_back(ConstantInt::get(IRB.getInt32Ty(),(uint32_t)cs));
			

            if(isa<LoadInst>(I))
            {
                I->getParent()->getInstList().insert
                    (I->getIterator(), CallInst::Create(checkReadFunc, Args,"")); 
            }
            else if(isa<StoreInst>(I))
            {
                 I->getParent()->getInstList().insert
                     (I->getIterator(), CallInst::Create(checkWriteFunc, Args,"")); 
            }

        }

        bool runOnModule(Module &M) override {
            for(Module::global_iterator gs=M.global_begin(), ge=M.global_end(); gs!=ge; ++gs) {
                errs().changeColor(raw_ostream::RED);
                errs() << "GloVar::iterator " << gs->getName()<<" ...\n";
				if (gs->getName()=="sharedVar")
				{
					sharedGV=dyn_cast<GlobalVariable> (gs);
				}
            }

            for(Module::iterator F=M.begin(); F!=M.end(); ++F) {
                errs().changeColor(raw_ostream::GREEN);
                errs() << "Function::iterator " << F->getName()<<" ...\n";
                errs().resetColor();

					unsigned int j=0;
					unsigned int tmp=1;
					l_locks lock1[3];
					l_locks lock2[3];
					string mutex_cnt[10];
					lock1[0]={0,0, NULL, &sharedGV, 0};
					lock2[0]={0,0, NULL, &sharedGV, 0};
							
					lock1[1]={0,0, NULL, &sharedGV, 0};
					lock2[1]={0,0, NULL, &sharedGV, 0};
							
					lock1[2]={0,0, NULL, &sharedGV, 0};
					lock2[2]={0,0, NULL, &sharedGV, 0};
							
                for (Function::iterator BB=F->begin(), EE=F->end(); BB!=EE; ++BB) {

                    errs().changeColor(raw_ostream::YELLOW);
                    errs() << "BasicBlock::iterator" << BB->getName()<< " ...\n";                    
                    errs().resetColor();
                    unsigned int loadnum=1;
					unsigned int storenum=1;

                    for (BasicBlock::iterator I=BB->begin(), E=BB->end(); I!=E; ++I) {
                        for (Use &U : I->operands()) {
							   /*if(U->getName()=="sharedVar") {
                                        while(cnt) {                                          
											j=1;
                                            cnt=0;
                                        } 
                            	}*/

								unsigned int k;
                                if (U->getName()=="__kmpc_critical") {
									j=tmp;
																	
                                    errs()<<"push:"<<(*I->getOperand(2)).getName()<<"\n";
                                        for (k=1; k<=j; k++)
                                        {
                                            if (mutex_cnt[k]==(*I->getOperand(2)).getName()) {
                                                errs()<<mutex_cnt[k]<<","<<k<<"이미 있는것 \n";
												j=k;												
                                                break;
                                            }
                                            else if (j==k)
                                            {   
                                                // errs()<<"j의 값"<<j<<"\n";
                                                mutex_cnt[j]=(*I->getOperand(2)).getName();
                                                errs()<<mutex_cnt[j]<<","<<j<<"새로 삽입한 것 \n";
												if (F->getName()=="_Z5task1i") 
												{
                                                	lock1[j]={0,0,&mutex_cnt[j],&sharedGV,0};
                                                } else if (F->getName()=="_Z5task2i") 
												{
                                                	lock2[j]={0,0,&mutex_cnt[j],&sharedGV,0};
                                                }
												tmp++;
                                                break;
                                            }
                                        } //for fin
								} //if_lock fin		

							 else if (U->getName()=="__kmpc_end_critical") {
								errs().changeColor(raw_ostream::GREEN);
								errs() <<" biimgye\n" ;								
								j=0;
							  }
                            errs().resetColor();
                        }// for (Use ~)

						if(F->getName()=="_Z5task1i" || F->getName()=="_Z5task2i")
						{
                           if (isa<LoadInst> (I) || isa<StoreInst>(I)) { 
		                       for (unsigned int i=0; i<I->getNumOperands(); i++)
		                       {
		                           if (sharedGV==dyn_cast<GlobalVariable>(I->getOperand(i)))
		                           {//공유변수에 접근함을 확인하면 그 전에 insert_Func 넣기 
										errs().changeColor(raw_ostream::BLUE);
										errs() << sharedGV->getName() << ": sharedgv name\n";
										if(isa<LoadInst> (I)) 
										{
											errs().changeColor(raw_ostream::RED);
											errs()<<"read="<<loadnum<<"\n";
											loadnum++;
											errs().resetColor();
										} else if (isa<StoreInst> (I))
										{
											errs().changeColor(raw_ostream::BLUE);
											errs()<<"write="<<storenum<<"\n";
											storenum++;
										}
										errs().resetColor();
										Instruction *it=dyn_cast<Instruction> (I);

										if(F->getName()=="_Z5task1i")
										{
											insert_Func(it, &lock1[0], &lock1[j]);					
											errs()<<"insert complete: j의 값"<<j<<"\n";
										}
										else if (F->getName()=="_Z5task2i")
										{
											insert_Func(it, &lock2[0], &lock2[j]);
											errs()<<"insert complete: j의 값"<<j<<"\n";
										}
		                            }
		                        }
                            } //스레드 함수를 위한 if문 끝 
						} 
                } //basic block 끝 
            }//Function

            }//Module
        return false;
        }// end of runOnModule

        private:
            Module *Mod;
            Constant *checkReadFunc;
            Constant *checkWriteFunc;
			//Constant *PrintFunc;
            //GlobalVariable *GV;
            GlobalVariable *sharedGV;
    };
    
}
     
char Filter::ID=0;
static RegisterPass<Filter> X("filter", "filter pass");
