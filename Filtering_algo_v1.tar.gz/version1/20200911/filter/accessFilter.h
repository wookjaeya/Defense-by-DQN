#include <stdbool.h>
// struct for each locks and vars.
// must be declared and initialized at entry point of each thread
// which uses shared variable or lock.
// pointer cs and sharedVar can be used for detection protocol.

typedef struct L_LOCKS
{
	int read;
	int write;
	int filter_done;

	int sv_id;		// id of a shared varaible
	int cs_id;		// id of a critical section
	int thread_id;	// id of a thread
} L_LOCKS;


typedef struct NODE{
	struct NODE *next;
	L_LOCKS *data;
} NODE;

int checkRead(int sv_id, int cs_id);
int checkWrite(int sv_id, int cs_id);

NODE *search(int sv_id, int cs_id, int thread_id);
NODE *append();

//void showResult(void);