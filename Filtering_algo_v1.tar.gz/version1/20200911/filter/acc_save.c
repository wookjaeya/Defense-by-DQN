// 2019. 10. 02.
// Keonpyo Lee

#include "accessFilter.h"
#include <stdio.h>
#include <omp.h>

int read_cnt=0;
int filter_read=0;
int write_cnt=0;
int filter_write=0;

int local_read_cnt1=0;int local_read_cnt2=0;
int local_write_cnt=0;

int checkRead(l_locks *ncs, l_locks *cs)
{
	int my_rank=omp_get_thread_num();
	//printf("checkRead\n");//for test
	read_cnt++;

	if(ncs->filter_done) { //problem point
		//return 0; //SKIPPED
		printf("ncs->filter_done, %d\n", my_rank); 
	}
	else if (cs==ncs)
	{
		if (ncs->read) 
		{
			//return 5;
			printf("ncs->read, %d\n", my_rank);
		}
	 	else 
		{
			printf("ncs->not read, %d\n", my_rank);
			ncs->read=1;
			filter_read++;
			/* insert detection protocol "CheckReadFiltered" here */
			//return 1; //READ_FINALLY_FILTERED
		}
	}
	else
	{
		if (ncs->read) 
		{
			printf("ncs->read, %d\n", my_rank);
			//return 5;
		}
		else if (cs->write || cs->read) 
		{	
			printf("cs->write || cs->read, %d\n", my_rank);
			//return 0; 
		}
		else
		{
			/* insert detection protocol "CheckCSReadFiltered" here */
			printf("not yet, %d\n", my_rank);
			cs->read = 1;
			filter_read++;
			//return 2; //READ_FILTERED
		}
	}
	
	if (my_rank==0) local_read_cnt1++;
	else if (my_rank==1)  local_read_cnt2++;
	return 0; //SKIPPED
}

int checkWrite(l_locks *ncs, l_locks *cs)
{
	int my_rank=omp_get_thread_num();
	write_cnt++;
	if (ncs->filter_done)
	{
		return 0; //SKIPPED
	}

	else if (cs==ncs)
	{
		if (!ncs->read)
		{
			/* insert detection protocol "CheckWriteFiltered" here */
		}
		else
		{
			/* insert detection protocol "CheckR_WriteFiltered" here */
		}
		filter_write++;
		ncs->filter_done = 1;
		ncs->write=1;
		return 3; //WRITE_FINALLY_FILTERED;
	}
	else
	{
		if (!cs->read && !cs->write)
		{
			/* insert detection protocol "CheckCSWriteFiltered" here */
		}
		else if (cs->read && !cs->write)
		{
			/* insert detection protocol "CheckCSR_WriteFiltered" here */
		}
		filter_write++;
		cs->write = 1;
		return 4; //WRITE_FILTERED
	}
	return 0; //SKIPPED
}

/*int valueRead(void)
{
	//return read_cnt;
	printf("Read Num: %d\n", read_cnt);
}

int valueWrite(void)
{
	return write_cnt;
}

int filterRead(void)
{
	//return filter_read;
	printf("filter_Read Num: %d\n", filter_read);
}

int filterWrite(void)
{
	return filter_write;
}*/

void print_num(void)
{
	//printf("read num: %d\n", read_cnt);
	//printf("write num: %d\n", write_cnt);	

	int filter_sum=filter_read+filter_write;
	printf("6. # of filtered event : %d \n", filter_sum);
	printf("7. # of filtered Read event : %d / # of filtered Write event: %d \n", filter_read, filter_write);
	printf("8. # of filtered event per shared Variable : %d \n", filter_sum);
	printf("9. # of filtered Read event per shared Variable : %d / # of filtered Write event per shared Variable : %d \n", filter_read, filter_write);
}
