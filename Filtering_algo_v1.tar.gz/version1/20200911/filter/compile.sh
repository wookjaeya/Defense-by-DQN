clang -g -ggdb -S -emit-llvm LLVM_omp.cpp -c -fopenmp -o ex.bc
sleep .2
clang -g -ggdb -S -emit-llvm accessFilter.c -c -o pref.bc
sleep .2
llvm-link pref.bc ex.bc -S -o=ex_M.bc
sleep .2
opt -load /home/odroid/LLVM/llvm-8.0.0.src/build/lib/Filter.so -filter <ex_M.bc> ex_T.bc
sleep .2
llc ex_T.bc -o ex_T.s
sleep .2
clang -g -ggdb ex_T.s -fopenmp -o ex_T.native -lstdc++ -lffi
sleep .2
./ex_T.native
