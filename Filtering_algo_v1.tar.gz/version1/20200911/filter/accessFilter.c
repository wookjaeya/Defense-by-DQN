// 2019. 10. 02.
// created by Keonpyo Lee
//

#include "accessFilter.h"
#include <stdio.h>
#include <omp.h> 

int read_cnt = 0;
int filter_read = 0;
int write_cnt = 0;
int filter_write = 0;

// l_locks[thread][critical section]
NODE *head = NULL;
NODE *tail = NULL;

// 공유변수, 임계구역, 스레드
int checkRead(int sv_id, int cs_id)
{
	int thread_id = omp_get_thread_num();
	//입력 파라미터와 동일한 l_lcoks를 검색
	NODE *current = search(sv_id, cs_id, thread_id);
	//조건에 맞는 l_lock가 없다면 새로 생성	
	if(current == NULL) 
	{
		current = append(sv_id, cs_id, thread_id);
	}

	// [알고리즘 4]
	// 비임계구역에서 처음으로 변수 x에 대한 쓰기 사건이 발생한 이후의 사건은 검사하지 않음
	if ( current->data->filter_done == true) return 0;
	if ( cs_id == 0) 
	{
		if( current->data->read == false)
		{
			//CheckReadFiltered(sv_id, 0, thread_id);
			current->data->read = true;
			filter_read++;
		}
	}
	else
	{			
		NODE *ncs = search(sv_id, 0, thread_id);
		if(ncs == NULL) ncs = append(sv_id, 0, thread_id);

		if( current->data->read == false && ncs->data->read == false )
		{
			//CheckCSReadFiltered(sv_id, cs_id, thread_id);
			current->data->read = true;
			filter_read++;
		}
	}
	return 0; //SKIPPED
}

int checkWrite(int sv_id, int cs_id)
{	
	int thread_id = omp_get_thread_num();
	//printf("WRCHK-|%d|%d|%d|\n", sv_id, cs_id, thread_id);
	//입력 파라미터와 동일한 l_lcoks를 검색
	NODE *current = search(sv_id, cs_id, thread_id);
	//조건에 맞는 l_lock가 없다면 새로 생성
	if(current == NULL) 
	{
		current = append(sv_id, cs_id, thread_id);
	}

	// [알고리즘 4]
	// 비임계구역에서 처음으로 변수 x에 대한 쓰기 사건이 발생한 이후의 사건은 검사하지 않음
	if ( current->data->filter_done == true) return 0;
	
	if ( cs_id == 0) 
	{
		//비임계영역에 있는 접근사건인 경우
		if( current->data->read == false)
		{
			//checkWriteFiltered(sv_id, 0, thread_id);
		}
		else
		{
			//checkR-writeFiltered(sv_id, 0, thread_id);
		}

		current->data->write = true;
		current->data->filter_done = true;
	}
	else
	{
		if ( current->data->read == false && current->data->write == false )
		{
			//checkCSWriteFiltered(sv_id, cs_id, thread_id);
		}
		else if ( current->data->read == true && current->data->write == false )
		{
			//checkCSR-writeFiltered(sv_id, cs_id, thread_id);
		}
		
		printf("LOG: Write |%d|%d|%d|%d|%d|%d|\n",
		current->data->thread_id, current->data->sv_id, current->data->cs_id,
		current->data->read, current->data->write, current->data->filter_done);

		current->data->write = true;
		filter_write++;
	}
	return 0; //SKIPPED
}

NODE *search (int sv_id, int cs_id, int thread_id)
{	
	NODE *target = head;
	
	int count = 0;
	while ( target != NULL )
	{
		if(target->data->sv_id == sv_id && target->data->cs_id == cs_id && target->data->thread_id == thread_id)
		{
			return target;
		}		
		target = target->next;
		count++;
	}

	return NULL;
}

NODE *append(int sv_id, int cs_id, int thread_id)
{
	NODE *node = (NODE *)malloc(sizeof(NODE));
	node->next = NULL;
	node->data = (L_LOCKS *)malloc(sizeof(L_LOCKS));
		
	node->data->read = 0;
	node->data->write = 0;
	node->data->filter_done = 0;

	node->data->sv_id = sv_id;
	node->data->cs_id = cs_id;
	node->data->thread_id = thread_id;

	if(head == NULL)
	{		 
		 head = node;
		 tail = node;
	}
	else
	{
		tail->next = node;
		tail = node;
	}

	return node;	
}

void showResult(void)
{
	int filter_sum=filter_read+filter_write;
	printf("6. # of filtered event : %d \n", filter_sum);
	printf("7. # of filtered Read event : %d / # of filtered Write event: %d \n", filter_read, filter_write);
	printf("8. # of filtered event per shared Variable : %d \n", filter_sum);
	printf("9. # of filtered Read event per shared Variable : %d / # of filtered Write event per shared Variable : %d \n", filter_read, filter_write);

	NODE *target = head;
	printf("10. filter Result\n");
	printf("| thread |   sv   |   cs   |  read  | write  |   fd   |\n");
	
	int count = 0;
	while ( target != NULL )
	{		
		printf("|%8d|%8d|%8d|%8d|%8d|%8d|\n",
		target->data->thread_id, target->data->sv_id, target->data->cs_id,
		target->data->read, target->data->write, target->data->filter_done);

		target = target->next;	
		count++;
	}

	printf("# of nodes: %d\n", count);	
}
