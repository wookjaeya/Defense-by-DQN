# Filtering code of "Scalable Monitoring Technique for Detecting Races in Parallel Programs with Locking"

## Compile procedure

clang -S -emit-llvm LLVM_omp.cpp -c -fopenmp -o ex.bc
clang -S -emit-llvm accessFilter.c -c -o pref.bc
llvm-link pref.bc ex.bc -S -o=ex_M.bc
opt -load /home/odroid/LLVM/llvm/build/lib/Filter.so -filter <ex_M.bc> ex_T.bc
llc ex_T.bc -o ex_T.s
clang ex_T.s -fopenmp -o ex_T.native -lstdc++ -lffi
./ex_T.native

## Credits

Keonpyo Lee
Seung-Eun Lee


