#include <stdio.h>
//#ifdef _OPENMP
#include <omp.h>
#include "accessFilter.h"

void task1(int rank1);
void task2(int rank2);

extern "C" void showResult(void);

int sharedVar = 10;
int readNum = 0;
int writeNum = 0;

int main()
{	
	printf("\n **************************** Program before Filtering ****************************\n");
	int thread_num=2;
	printf("1. # of Threads : %d / # of Locking : 2 \n", thread_num);
	printf("2. # of Shared Variable : 1 \n");

	#pragma omp parallel num_threads(thread_num)
	{
		int my_rank=omp_get_thread_num();
		//not at this

		printf("My rank : %d\n", my_rank);

		if (my_rank==0)
		{
			task1(my_rank);
		}
		else if (my_rank==1)
		{
			task2(my_rank);
		}
		else 
		{
			printf("error\n");
		}
	} //end of parallel
	printf("3. # of access event : %d \n", readNum+writeNum);
	printf("4. # of access event per Shared Variable : %d \n", readNum+writeNum);
	printf("5. # of read event : %d / # of write event: %d\n ", readNum, writeNum);
	printf("\n ****************************** Program after Filtering *******************************\n");

	showResult();
}

void task1(int rank1)
{
	printf("task1[%d]\n", omp_get_thread_num());

	int localVar[6]={0};
	#pragma omp critical(cs1)
	{		
		localVar[0]=sharedVar;
		readNum++;

		localVar[1]=sharedVar;
		readNum++;
	}
		
	localVar[2]=sharedVar;
	readNum++;

	#pragma omp critical(cs2)
	{
		localVar[3]=sharedVar;
		readNum++;
		sharedVar=8;
		writeNum++;
	}            

	#pragma omp critical(cs1)
	{
		localVar[4]=sharedVar;
		readNum++;
		sharedVar=2;
		writeNum++;
	}       
	
	localVar[5]=sharedVar;
	readNum++;
	sharedVar=17;   
	writeNum++;
}

void task2(int rank2)
{
	printf("task2[%d]\n", omp_get_thread_num());

	int localVar[6]={0};
	localVar[0]=sharedVar;
	readNum++;

	#pragma omp critical(cs1)
	{
		localVar[1]=sharedVar;
		readNum++;
		sharedVar=4;
		writeNum++;
	}

	localVar[2]=sharedVar;
	readNum++;
	localVar[3]=sharedVar;
	readNum++;

	sharedVar=5;
	writeNum++;
 
	#pragma omp critical(cs2)
	{
		localVar[4]=sharedVar;
		readNum++;
		sharedVar=4;
		writeNum++;
	}            
}	
